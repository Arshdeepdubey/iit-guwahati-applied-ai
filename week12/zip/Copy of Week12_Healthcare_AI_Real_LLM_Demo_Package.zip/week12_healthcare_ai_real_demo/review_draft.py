from __future__ import annotations
import argparse, json
from pathlib import Path
from src.audit import log_event, sha256_text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default="outputs")
    ap.add_argument("--decision", choices=["approve", "revise", "reject"], default=None)
    ap.add_argument("--comment", default="")
    args = ap.parse_args()
    out = Path(args.out_dir)
    draft_file = out / "llm_draft.md"
    if not draft_file.exists():
        draft_file = out / "deterministic_summary.md"
    draft = draft_file.read_text()
    print("\n=== DRAFT FOR HUMAN REVIEW ===\n")
    print(draft)
    decision = args.decision or input("\nDecision [approve/revise/reject]: ").strip().lower()
    if decision not in {"approve", "revise", "reject"}:
        raise SystemExit("Invalid decision")
    comment = args.comment or input("Review comment: ").strip()
    rec = {
        "decision": decision,
        "comment": comment,
        "draft_sha256": sha256_text(draft),
        "human_review_required": True,
    }
    (out / "clinician_review.json").write_text(json.dumps(rec, indent=2))
    log_event(out / "audit.jsonl", "human_review_recorded", rec)
    print("\nReview recorded:")
    print(json.dumps(rec, indent=2))


if __name__ == "__main__":
    main()
