from __future__ import annotations
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM


def generate(messages, model_id: str, max_new_tokens: int = 650, temperature: float = 0.0):
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype="auto", device_map="auto")
    inputs = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=True,
        return_dict=True,
        return_tensors="pt",
    ).to(model.device)
    kwargs = {"max_new_tokens": int(max_new_tokens), "do_sample": temperature > 0}
    if temperature > 0:
        kwargs["temperature"] = float(temperature)
    with torch.no_grad():
        output = model.generate(**inputs, **kwargs)
    new_tokens = output[0][inputs["input_ids"].shape[-1]:]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
