from __future__ import annotations
import json


def build_prompt(facts: dict, score: dict, evidence: list[dict]) -> list[dict]:
    evidence_text = "\n\n".join(
        f"SOURCE ID: {e['source_id']}\nTITLE: {e['title']}\nEVIDENCE: {e['text']}\nURL: {e['source_url']}"
        for e in evidence
    )
    system = (
        "You are an educational clinical decision-support summarizer for a classroom demonstration. "
        "Use only the supplied synthetic patient facts, deterministic score, and retrieved evidence. "
        "Do not invent missing facts. Do not identify a real person. Do not issue autonomous treatment orders. "
        "Do not generate drug doses. Keep clinical decisions with the clinician. "
        "Cite evidence using the supplied SOURCE IDs in square brackets."
    )
    user = (
        "SYNTHETIC PATIENT FACTS\n" + json.dumps(facts, indent=2) +
        "\n\nDETERMINISTIC SCORE\n" + json.dumps(score, indent=2) +
        "\n\nRETRIEVED EVIDENCE\n" + evidence_text +
        "\n\nTASK\nCreate a concise clinical decision-support draft with these headings:\n"
        "1. Patient snapshot\n2. Deterministic severity score\n3. Evidence-grounded considerations\n"
        "4. Missing information or uncertainty\n5. Clinician review checklist\n\n"
        "Rules:\n- Repeat the deterministic score exactly; do not recalculate it.\n"
        "- Every clinical statement derived from guidance must cite one or more SOURCE IDs.\n"
        "- If a fact is absent, say 'not provided'.\n- Do not prescribe a specific drug or dose.\n"
        "- End with: 'Educational demonstration only; clinician review is required.'\n"
    )
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]
