from __future__ import annotations
from typing import Dict, Any


def calculate_curb65(facts: Dict[str, Any], setting: str = "hospital") -> Dict[str, Any]:
    setting = setting.lower()
    if setting not in {"hospital", "primary_care"}:
        raise ValueError("setting must be hospital or primary_care")

    common = {
        "confusion": facts.get("new_confusion"),
        "respiratory_rate": facts.get("respiratory_rate_bpm"),
        "systolic_bp": facts.get("systolic_bp_mmhg"),
        "diastolic_bp": facts.get("diastolic_bp_mmhg"),
        "age": facts.get("age_years"),
    }
    missing = [k for k, v in common.items() if v is None]
    if setting == "hospital" and facts.get("urea_mmol_l") is None:
        missing.append("urea_mmol_l")

    if missing:
        return {
            "tool": "CURB65" if setting == "hospital" else "CRB65",
            "computable": False,
            "missing_inputs": missing,
            "score": None,
            "risk_category": "not computed",
            "components": {},
            "note": "The score is not computed because required input data are missing.",
        }

    components = {
        "confusion": 1 if bool(common["confusion"]) else 0,
        "respiratory_rate_ge_30": 1 if float(common["respiratory_rate"]) >= 30 else 0,
        "low_blood_pressure": 1 if (float(common["systolic_bp"]) < 90 or float(common["diastolic_bp"]) <= 60) else 0,
        "age_ge_65": 1 if int(common["age"]) >= 65 else 0,
    }
    if setting == "hospital":
        components["urea_gt_7_mmol_l"] = 1 if float(facts["urea_mmol_l"]) > 7 else 0

    score = sum(components.values())
    if setting == "hospital":
        category = (
            "low risk (NICE: <3% mortality risk)" if score <= 1 else
            "intermediate risk (NICE: 3% to 15% mortality risk)" if score == 2 else
            "high risk (NICE: >15% mortality risk)"
        )
    else:
        category = (
            "low risk (NICE: <1% 30-day mortality risk)" if score == 0 else
            "intermediate risk (NICE: 1% to 10% 30-day mortality risk)" if score <= 2 else
            "high risk (NICE: >10% 30-day mortality risk)"
        )

    return {
        "tool": "CURB65" if setting == "hospital" else "CRB65",
        "computable": True,
        "score": score,
        "risk_category": category,
        "components": components,
        "missing_inputs": [],
        "note": "Use the score with clinical judgement; it is not an autonomous disposition decision.",
    }
