from __future__ import annotations
from datetime import date
from typing import Any, Dict


def _age_on(birth_date: str, encounter_date: str) -> int:
    b = date.fromisoformat(birth_date)
    d = date.fromisoformat(encounter_date)
    return d.year - b.year - ((d.month, d.day) < (b.month, b.day))


def extract_case(bundle: Dict[str, Any], encounter_date: str) -> Dict[str, Any]:
    resources = [e.get("resource", {}) for e in bundle.get("entry", [])]
    patient = next((r for r in resources if r.get("resourceType") == "Patient"), None)
    if not patient:
        raise ValueError("FHIR Bundle has no Patient resource.")

    obs = {r.get("id"): r for r in resources if r.get("resourceType") == "Observation"}
    conditions = [
        r.get("code", {}).get("text", "Unknown condition")
        for r in resources if r.get("resourceType") == "Condition"
    ]

    def q(obs_id):
        r = obs.get(obs_id)
        return None if not r else r.get("valueQuantity", {}).get("value")

    def b(obs_id):
        r = obs.get(obs_id)
        return None if not r else r.get("valueBoolean")

    return {
        "patient_id": patient.get("id"),
        "display_name": (patient.get("name") or [{}])[0].get("text", "Synthetic patient"),
        "birth_date": patient.get("birthDate"),
        "age_years": _age_on(patient["birthDate"], encounter_date),
        "gender": patient.get("gender"),
        "conditions": conditions,
        "respiratory_rate_bpm": q("resp-rate"),
        "systolic_bp_mmhg": q("sys-bp"),
        "diastolic_bp_mmhg": q("dia-bp"),
        "oxygen_saturation_pct": q("spo2"),
        "temperature_c": q("temp"),
        "urea_mmol_l": q("urea"),
        "new_confusion": b("confusion"),
        "heart_rate_bpm": q("heart-rate"),
        "synthetic_case": True,
    }
