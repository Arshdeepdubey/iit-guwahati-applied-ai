from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def log_event(path: str | Path, event_type: str, payload: dict):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rec = {"timestamp_utc": datetime.now(timezone.utc).isoformat(), "event_type": event_type, **payload}
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec
