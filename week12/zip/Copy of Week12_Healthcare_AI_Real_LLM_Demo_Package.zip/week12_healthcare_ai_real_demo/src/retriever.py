from __future__ import annotations
import json
from pathlib import Path
from typing import List, Dict, Any
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def load_corpus(path: str | Path) -> List[Dict[str, Any]]:
    docs = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            docs.append(json.loads(line))
    return docs


def retrieve(query: str, docs: List[Dict[str, Any]], top_k: int = 5, min_score: float = 0.0):
    texts = [d["title"] + " " + d["text"] for d in docs]
    vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    mat = vec.fit_transform(texts + [query])
    sims = cosine_similarity(mat[-1], mat[:-1]).ravel()
    order = sims.argsort()[::-1]
    out = []
    for idx in order[:top_k]:
        if float(sims[idx]) < min_score:
            continue
        item = dict(docs[idx])
        item["retrieval_score"] = round(float(sims[idx]), 4)
        out.append(item)
    return out
