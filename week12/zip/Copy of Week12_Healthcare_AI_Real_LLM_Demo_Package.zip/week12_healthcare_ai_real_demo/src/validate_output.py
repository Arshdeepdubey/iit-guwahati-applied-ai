from __future__ import annotations
import re


def validate_llm_output(text: str, score: dict, evidence: list[dict]) -> dict:
    allowed = {e["source_id"] for e in evidence}
    cited = set(re.findall(r"\[([A-Z0-9][A-Z0-9\-\.]+)\]", text))
    unknown = sorted(cited - allowed)
    expected_score = str(score.get("score")) if score.get("computable") else None
    score_mentioned = True if expected_score is None else (expected_score in text)
    closing = "Educational demonstration only; clinician review is required."
    return {
        "allowed_source_ids": sorted(allowed),
        "cited_source_ids": sorted(cited),
        "unknown_source_ids": unknown,
        "citation_integrity_ok": len(unknown) == 0,
        "deterministic_score_value_present": score_mentioned,
        "required_closing_present": closing.lower() in text.lower(),
        "passes_basic_checks": len(unknown) == 0 and score_mentioned and closing.lower() in text.lower(),
        "note": "These checks are limited. Human review remains required.",
    }
