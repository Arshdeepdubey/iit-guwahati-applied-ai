import json, yaml
from src.fhir_extract import extract_case
from src.curb65 import calculate_curb65
from src.retriever import load_corpus, retrieve

cfg = yaml.safe_load(open("config.yaml"))
b = json.load(open("data/case_hospital_cap_fhir.json"))
f = extract_case(b, cfg["scenario"]["encounter_date"])
assert f["age_years"] == 68
s = calculate_curb65(f, "hospital")
assert s["computable"] and s["score"] == 2, s
assert s["components"]["respiratory_rate_ge_30"] == 1
assert s["components"]["age_ge_65"] == 1
assert s["components"]["urea_gt_7_mmol_l"] == 0

b2 = json.load(open("data/case_primary_care_cap_fhir.json"))
f2 = extract_case(b2, cfg["scenario"]["encounter_date"])
s2 = calculate_curb65(f2, "primary_care")
assert s2["computable"] and s2["tool"] == "CRB65" and s2["score"] == 1, s2

corpus = load_corpus("data/guideline_nice_ng250.jsonl")
r = retrieve("hospital pneumonia CURB65 severity place of care", corpus, top_k=3)
assert r and any(x["source_id"] == "NICE-NG250-1.2.7" for x in r)

print("ALL DETERMINISTIC SMOKE TESTS PASSED")
print("Hospital CURB65:", s)
print("Primary-care CRB65:", s2)
