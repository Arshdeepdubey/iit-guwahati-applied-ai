# References used in the package

1. NICE. Pneumonia: diagnosis and management (NG250). Published 2 September 2025. https://www.nice.org.uk/guidance/ng250/chapter/recommendations
2. HL7 FHIR R4 Observation: https://hl7.org/fhir/R4/observation.html
3. HL7 FHIR R4 Condition: https://hl7.org/fhir/R4/condition.html
4. LOINC 9279-1 Respiratory rate: https://loinc.org/9279-1
5. LOINC 59408-5 Oxygen saturation by pulse oximetry: https://loinc.org/59408-5
6. Qwen/Qwen2.5-1.5B-Instruct: https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct

The NICE evidence items are short paraphrases with source IDs and URLs, not copied guideline passages.
