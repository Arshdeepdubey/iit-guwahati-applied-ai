# Instructor Runbook - Week 12 Healthcare AI Demo

## Teaching goal

Students should understand a safe clinical-AI pattern:

**structured patient data -> deterministic clinical tool -> evidence retrieval -> LLM synthesis -> human review -> audit log**

The LLM is deliberately *not* used to calculate CURB65. It is used only after the factual and deterministic steps are complete.

## 90-minute demonstration flow

### Part A - Establish the case (10 min)
1. Open `data/case_hospital_cap_fhir.json`.
2. Point out that it is a synthetic FHIR Bundle, not a real patient record.
3. Show Patient, Condition, and Observation resources.
4. Ask students which values are required for CURB65.

Expected values:
- age 68 -> 1 point,
- new confusion false -> 0,
- urea 6.2 mmol/L -> 0,
- respiratory rate 32/min -> 1,
- BP 118/72 -> 0.

Expected CURB65 = 2.

### Part B - Deterministic severity calculation (10 min)
Run:

```bash
python run_demo.py --skip-llm --out-dir outputs_deterministic
```

Open `severity_score.json`.

Explain why a clinical score should be implemented as auditable deterministic code when the rule is known. The LLM should not be asked to infer or recalculate a score from prose.

### Part C - RAG over real guideline evidence (15 min)
Open `data/guideline_nice_ng250.jsonl`.

Each item contains:
- source ID,
- short paraphrased evidence,
- recommendation number,
- official NICE URL.

Open `retrieved_evidence.json` and show that the TF-IDF retriever selects relevant guideline statements for hospital CAP, CURB65, and place of care.

Explain: this is real retrieval. The evidence is authoritative and identifiable. The LLM is not expected to remember the guideline from model weights.

### Part D - Real LLM generation (20 min)
Run:

```bash
python run_demo.py --out-dir outputs_real_llm
```

On first run, Hugging Face downloads `Qwen/Qwen2.5-1.5B-Instruct`.

Open `llm_prompt.json` before reading the answer. Show students the guardrails:
- use only supplied facts/evidence,
- do not invent missing facts,
- do not generate drug doses,
- cite source IDs,
- preserve clinician responsibility.

Then open `llm_draft.md`.

### Part E - Validate the LLM output (10 min)
Open `llm_validation.json`.

Explain what the automatic checks can and cannot do.

They can check:
- whether citations refer to retrieved source IDs,
- whether the deterministic score value appears,
- whether the required educational/clinician-review closing is present.

They cannot prove clinical correctness. Human review is still required.

### Part F - Human review and auditability (10 min)
Run:

```bash
python review_draft.py --out-dir outputs_real_llm
```

Record a decision and comment.

Then open `audit.jsonl` and show the sequence:
1. case loaded,
2. FHIR facts extracted,
3. score calculated,
4. evidence retrieved,
5. LLM started/completed,
6. output validated,
7. human review recorded.

### Part G - CRB65 vs CURB65 correctness check (10 min)
Show `data/case_primary_care_cap_fhir.json`.

Explain:
- primary care: CRB65, no urea component,
- hospital: CURB65, includes urea.

This distinction is important and should not be left to the LLM.

### Part H - Wrap-up (5 min)
End with the architecture:

**FHIR facts -> deterministic score -> source-backed RAG -> real LLM -> validation -> human approval -> audit**

Ask students: which stages are probabilistic, and which are deterministic?

Expected answer:
- FHIR parsing, score calculation, audit logging: deterministic.
- retrieval ranking: algorithmic but data/query dependent.
- LLM generation: generative.
- clinician approval: human judgement.
