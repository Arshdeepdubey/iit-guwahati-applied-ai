import requests
sources = {
    'NICE NG250': 'https://www.nice.org.uk/guidance/ng250/chapter/recommendations',
    'HL7 FHIR R4 Observation': 'https://hl7.org/fhir/R4/observation.html',
    'Qwen2.5-1.5B-Instruct': 'https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct',
}
for name, url in sources.items():
    try:
        r = requests.get(url, timeout=15, allow_redirects=True)
        print(f'{name}: HTTP {r.status_code} -> {r.url}')
    except Exception as e:
        print(f'{name}: check failed: {e}')
