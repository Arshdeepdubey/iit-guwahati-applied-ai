# Student Handout - Healthcare AI Demonstration

## Pipeline
FHIR patient data -> deterministic CURB65/CRB65 -> guideline retrieval -> real LLM summary -> human review -> audit log.

## Student tasks
1. Identify the Patient, Condition, and Observation resources in the synthetic FHIR Bundle.
2. Calculate the hospital CURB65 manually and verify the program result.
3. Explain why the primary-care variant uses CRB65 instead of CURB65.
4. Inspect the retrieved NICE evidence and identify which recommendation supports each statement in the LLM draft.
5. Find any sentence in the LLM draft that is not clearly supported by the patient facts or retrieved evidence.
6. Inspect `llm_validation.json` and explain why automatic checks do not replace clinical review.
7. Inspect `audit.jsonl` and reconstruct the complete tool-use sequence.

## Discussion questions
- Why should a known score formula be deterministic instead of delegated to an LLM?
- What happens if urea is missing in a hospital CURB65 calculation?
- Why is source-backed retrieval safer than asking an LLM to answer from memory?
- What kinds of hallucination can still occur even when RAG is used?
- Which data should be logged, and which should be minimized for privacy?
