from __future__ import annotations
import argparse, json, yaml
from pathlib import Path
from src.fhir_extract import extract_case
from src.curb65 import calculate_curb65
from src.retriever import load_corpus, retrieve
from src.prompting import build_prompt
from src.audit import log_event, sha256_text
from src.validate_output import validate_llm_output


def main():
    ap = argparse.ArgumentParser(description="Week 12 Healthcare AI real-LLM classroom demo")
    ap.add_argument("--case", default="data/case_hospital_cap_fhir.json")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--out-dir", default="outputs")
    ap.add_argument("--skip-llm", action="store_true", help="Run deterministic pipeline only.")
    ap.add_argument("--model-id", default=None)
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    audit = out / "audit.jsonl"
    audit.write_text("")

    bundle = json.loads(Path(args.case).read_text())
    log_event(audit, "case_loaded", {
        "case_file": args.case,
        "sha256": sha256_text(json.dumps(bundle, sort_keys=True)),
        "synthetic": True,
    })

    facts = extract_case(bundle, cfg["scenario"]["encounter_date"])
    (out / "patient_facts.json").write_text(json.dumps(facts, indent=2))
    log_event(audit, "fhir_extracted", {"patient_id": facts["patient_id"], "facts_file": "patient_facts.json"})

    score = calculate_curb65(facts, cfg["scenario"]["setting"])
    (out / "severity_score.json").write_text(json.dumps(score, indent=2))
    log_event(audit, "severity_score_calculated", {
        "tool": score["tool"], "computable": score["computable"],
        "score": score["score"], "missing_inputs": score["missing_inputs"],
    })

    docs = load_corpus("data/guideline_nice_ng250.jsonl")
    query = (
        f"{cfg['scenario']['clinical_diagnosis']} {cfg['scenario']['setting']} severity risk "
        f"place of care imaging clinical judgement comorbidities score {score.get('score')}"
    )
    evidence = retrieve(
        query, docs,
        top_k=int(cfg["retrieval"]["top_k"]),
        min_score=float(cfg["retrieval"]["min_score"]),
    )
    (out / "retrieved_evidence.json").write_text(json.dumps(evidence, indent=2))
    log_event(audit, "guideline_retrieval", {
        "query": query, "source_ids": [e["source_id"] for e in evidence]
    })

    lines = [
        "# Deterministic clinical decision-support summary",
        "",
        "**Synthetic teaching case. Not for clinical use.**",
        "",
        f"- Patient age: {facts['age_years']} years",
        f"- Respiratory rate: {facts['respiratory_rate_bpm']} /min",
        f"- Blood pressure: {facts['systolic_bp_mmhg']}/{facts['diastolic_bp_mmhg']} mmHg",
        f"- Urea: {facts['urea_mmol_l']} mmol/L",
        f"- New confusion: {facts['new_confusion']}",
        f"- {score['tool']}: {score['score']} ({score['risk_category']})",
        "",
        "## Retrieved evidence",
    ]
    for e in evidence:
        lines.append(f"- [{e['source_id']}] {e['text']} ({e['recommendation']})")
    lines += ["", "Clinician review is required. The score must be interpreted together with the full clinical picture."]
    (out / "deterministic_summary.md").write_text("\n".join(lines))

    if args.skip_llm:
        print("Deterministic pipeline complete. LLM skipped by request.")
        print(json.dumps({
            "facts": facts, "score": score,
            "retrieved_source_ids": [e["source_id"] for e in evidence],
        }, indent=2))
        return

    from src.llm import generate
    model_id = args.model_id or cfg["llm"]["model_id"]
    messages = build_prompt(facts, score, evidence)
    (out / "llm_prompt.json").write_text(json.dumps(messages, indent=2))
    log_event(audit, "llm_started", {
        "model_id": model_id,
        "prompt_sha256": sha256_text(json.dumps(messages, sort_keys=True)),
    })

    text = generate(
        messages, model_id,
        max_new_tokens=cfg["llm"]["max_new_tokens"],
        temperature=cfg["llm"]["temperature"],
    )
    (out / "llm_draft.md").write_text(text + "\n")
    log_event(audit, "llm_completed", {
        "model_id": model_id,
        "output_sha256": sha256_text(text),
        "output_file": "llm_draft.md",
    })

    validation = validate_llm_output(text, score, evidence)
    (out / "llm_validation.json").write_text(json.dumps(validation, indent=2))
    log_event(audit, "llm_output_validated", validation)

    print("\n=== DETERMINISTIC SCORE ===")
    print(json.dumps(score, indent=2))
    print("\n=== RETRIEVED SOURCES ===")
    for e in evidence:
        print(f"{e['source_id']}  score={e['retrieval_score']}  {e['title']}")
    print("\n=== REAL LLM DRAFT ===")
    print(text)
    print("\n=== BASIC VALIDATION ===")
    print(json.dumps(validation, indent=2))
    print("\nNext step: run review_draft.py to record a human review decision.")


if __name__ == "__main__":
    main()
